package chess.app;

import chess.board.ChessBoard;
import chess.enums.ChessColor;
import chess.enums.ChessPieceType;
import chess.enums.LocationX;
import chess.exceptions.InvalidCoordinateException;
import chess.exceptions.InvalidMoveException;
import chess.exceptions.InvalidPieceException;
import chess.figures.Bishop;
import chess.figures.Figure;
import chess.figures.King;
import chess.figures.Knight;
import chess.figures.Pawn;
import chess.figures.Queen;
import chess.figures.Rook;
import java.util.Scanner;



/**
 * Main.java
 * Controls input, prevents duplicate piece types, creates five Figure objects and a separate Bishop, checks their moves, and displays results.
 * Authors: Aredth Sanchez, Sofia Vargas, Ben Silva
 * <p><strong>Lab 3 and Lab 4 change history:</strong></p>
 * <ul>
 * <li>Date: 09/27/2026 (Lab 3)</li>
 * <li>Created the initial chess piece hierarchy and piece-type and column enums.</li>
 * <li>Added constructors, accessors, and initial movement checks.</li>
 * <li>Date: 09/29/2026 (Lab 3)</li>
 * <li>Added Pawn, Knight, Chessboard, and Main; collected six pieces in an array.</li>
 * <li>Added duplicate checks, input validation, and printed movement results.</li>
 * <li>Date: 10/20/2026 (Lab 4)</li>
 * <li>Refactored ChessPiece into abstract Figure implementing IntFigure.</li>
 * <li>Added IntFigure, IntBishop, and IntChessBoard interface contracts.</li>
 * <li>Updated Pawn, Rook, and Knight to extend Figure and implement moveTo.</li>
 * <li>Changed Bishop to implement IntBishop independently of Figure.</li>
 * <li>Updated Queen to extend Rook, implement IntBishop, and reuse Rook movement.</li>
 * <li>Kept King extending Queen and restricted both movement methods to one square.</li>
 * <li>Added ChessBoard implementing IntChessBoard for coordinate validation.</li>
 * <li>Replaced Column with LocationX and String colors with the ChessColor enum.</li>
 * <li>Organized the program into app, board, enums, exceptions, figures, and interfaces packages.</li>
 * <li>Added custom exceptions for invalid piece names, coordinates, and moves.</li>
 * <li>Updated user input handling to catch errors and prompt again.</li>
 * <li>Replaced the six-piece array with five Figure objects and a separate Bishop.</li>
 * <li>Updated duplicate detection to include Bishop and checked Bishop after array traversal.</li>
 * <li>Added readable toString overrides and updated result printing.</li>
 * <li>Added file and method documentation.</li>
 * </ul>
 *
 * @author Aredth Sanchez, Sofia Vargas, Ben Silva
 * @version 1.0 (Lab 5 documentation)
 * @since 2026-10-20
 * @see chess.board.ChessBoard
 */
public class Main {

    /**
     * Creates the application controller.
     *
     * Method author: Aredth Sanchez.
     */
    public Main() {
    }

    /**
     * Chessboard instance used to validate positions and coordinates.
     */
    private static final ChessBoard board = new ChessBoard();
    /**
     * Array holding the five non-bishop chess pieces.
     */
    private static final Figure[] pieceArray = new Figure[5];
    /**
     * Separate bishop selected by the user.
     */
    private static Bishop bishop;
    /**
     * Column of the currently entered starting square.
     */
    private static LocationX startColumn;
    /**
     * Row of the currently entered starting square.
     */
    private static int startRow;
    /**
     * Column of the destination square.
     */
    private static LocationX targetColumn;
    /**
     * Row of the destination square.
     */
    private static int targetRow;

    /**
     * Starts the program, collects six distinct pieces, checks their movement, and closes the input reader.
     *
     * Method author: Aredth Sanchez.
     * @param args command-line arguments; not used.
     */
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int nextFigureIndex = 0;

        for (int i = 0; i < 6; ++i) {

            ChessPieceType pieceType = getPieceType(input);

            while (isDuplicatePiece(pieceArray, bishop, pieceType)) {
                System.out.println("That piece type has already been selected. Try again.");
                pieceType = getPieceType(input);
            }

            ChessColor color = getColor(input);
            getPiecePosition(input, board);

            if (pieceType == ChessPieceType.BISHOP) {
                bishop = new Bishop(pieceType, color, startColumn, startRow);
            } else {
                pieceArray[nextFigureIndex] = createPiece(pieceType, color, startColumn, startRow);
                ++nextFigureIndex;
            }
        }

        getTargetPosition(input, board);

        for (Figure piece : pieceArray) {
            try {
                boolean canMove = piece.moveTo(targetColumn, targetRow);
                printMoveResult(piece.toString(), targetColumn, targetRow, canMove);
            } catch (InvalidMoveException e) {
                printMoveResult(piece.toString(), targetColumn, targetRow, false);
                System.out.println(e.getMessage());
            } catch (InvalidCoordinateException e) {
                System.out.println(e.getMessage());
            }
        }

        try {
            boolean canMove = bishop.moveToBishop(targetColumn, targetRow);
            printMoveResult(bishop.toString(), targetColumn, targetRow, canMove);
        } catch (InvalidMoveException e) {
            printMoveResult(bishop.toString(), targetColumn, targetRow, false);
            System.out.println(e.getMessage());
        } catch (InvalidCoordinateException e) {
            System.out.println(e.getMessage());
        }

        input.close();
    }

    /**
     * Prompts until the user enters a supported piece type.
     *
     * Method author: Aredth Sanchez.
     * @param input Scanner used to read user input.
     * @return A valid ChessPieceType value.
     */
    public static ChessPieceType getPieceType(Scanner input) {
        while (true) {

            System.out.println(
                "Select Piece Type (PAWN, ROOK, BISHOP, KNIGHT, KING, or QUEEN): "
            );

            String pieceType = input.nextLine().trim().toUpperCase();

            try{
                return parsePieceType(pieceType);
            } catch (InvalidPieceException e) {
                System.out.println(e.getMessage());
            }

        }
    }

    /**
     * Converts normalized piece-name text into an enum value.
     *
     * Method author: Aredth Sanchez.
     * @param text piece-name text that has already been trimmed and converted to uppercase.
     * @return The matching ChessPieceType value.
     * @throws chess.exceptions.InvalidPieceException text does not match a supported piece name.
     * @see chess.enums.ChessPieceType
     */
    public static ChessPieceType parsePieceType(String text) {

        try {
            return ChessPieceType.valueOf(text);
        } catch (IllegalArgumentException e) {
            throw new InvalidPieceException(
                "Invalid piece type. Enter PAWN, ROOK, BISHOP, KNIGHT, KING, or QUEEN."
            );
        }
    }

    /**
     * Checks the Figure array and separate Bishop for a previously selected type.
     *
     * Method author: Aredth Sanchez.
     * @param pieceArray array of Figure objects already collected; unfilled elements may be null.
     * @param bishop separate Bishop object, or null if it has not been collected.
     * @param piece piece type to check for duplication.
     * @return true if the type has already been selected; false otherwise.
     */
    public static boolean isDuplicatePiece(Figure[] pieceArray, Bishop bishop, ChessPieceType piece) {

        if (piece == ChessPieceType.BISHOP && bishop != null) {
            return true;
        }

        for (Figure chessPiece : pieceArray) {
            if (chessPiece != null && chessPiece.getPieceName() == piece) {
                return true;
            }
        }

        return false;
    }

    /**
     * Prompts until the user enters WHITE or BLACK.
     *
     * Method author: Aredth Sanchez.
     * @param input Scanner used to read user input.
     * @return A valid ChessColor value.
     */
    public static ChessColor getColor(Scanner input) {

        while (true) {

            System.out.println("Select Piece Color (WHITE or BLACK): ");
            String color = input.nextLine().trim().toUpperCase();

            try {
                return ChessColor.valueOf(color);
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid Color. Enter WHITE or BLACK. Try again.");
            }
        }
    }

    /**
     * Prompts for valid target coordinates and stores them in targetColumn and targetRow.
     *
     * Method author: Aredth Sanchez.
     * @param input Scanner used to read user input.
     * @param board ChessBoard used to validate positions.
     */
    public static void getTargetPosition(Scanner input, ChessBoard board) {

        boolean validPosition = false;

        while (!validPosition) {

            System.out.print("Enter target column (a-h): ");
            String columnInput = input.nextLine().trim();

            System.out.print("Enter target row (1-8): ");
            String rowInput = input.nextLine().trim();

            if (columnInput.length() == 1) {

                try {
                    LocationX column = LocationX.valueOf(columnInput.toUpperCase());
                    int row = Integer.parseInt(rowInput);

                    if (board.verifyCoordinate(column, row)) {
                        targetColumn = column;
                        targetRow = row;
                        validPosition = true;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid row. Enter a whole number from 1 to 8.");
                } catch (InvalidCoordinateException e) {
                    System.out.println(e.getMessage());
                } catch (IllegalArgumentException e) {
                    System.out.println("Invalid column. Enter one letter from A through H.");
                }

            } else {
                System.out.println("Invalid column. Enter one letter from A through H.");
            }
        }
    }

    /**
     * Prompts for valid starting coordinates and stores them in startColumn and startRow.
     *
     * Method author: Aredth Sanchez.
     * @param input Scanner used to read user input.
     * @param board ChessBoard used to validate positions.
     */
    public static void getPiecePosition(Scanner input, ChessBoard board) {

        boolean validPosition = false;

        while (!validPosition) {

            System.out.print("Enter start column (a-h): ");
            String columnInput = input.nextLine().trim();

            System.out.print("Enter start row (1-8): ");
            String rowInput = input.nextLine().trim();

            if (columnInput.length() == 1) {

                try {
                    LocationX column = LocationX.valueOf(columnInput.toUpperCase());
                    int row = Integer.parseInt(rowInput);

                    if (board.verifyCoordinate(column, row)) {
                        startColumn = column;
                        startRow = row;
                        validPosition = true;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid row. Enter a whole number from 1 to 8.");
                } catch (InvalidCoordinateException e) {
                    System.out.println(e.getMessage());
                } catch (IllegalArgumentException e) {
                    System.out.println("Invalid column. Enter one letter from A through H.");
                }

            } else {
                System.out.println("Invalid column. Enter one letter from A through H.");
            }
        }
    }

    /**
     * Creates a Figure subclass for the selected type; Bishop is created separately in main.
     *
     * Method author: Aredth Sanchez.
     * @param pieceType selected chess piece type.
     * @param color piece color as a ChessColor value.
     * @param column column of the position as a LocationX value.
     * @param row row number of the position.
     * @return A Pawn, Rook, Knight, King, or Queen object as a Figure.
     * @throws chess.exceptions.InvalidPieceException type is null, BISHOP, or otherwise unsupported.
     * @throws chess.exceptions.InvalidCoordinateException starting coordinates are invalid.
     * @throws IllegalArgumentException color is null.
     */
    public static Figure createPiece(ChessPieceType pieceType, ChessColor color, LocationX column, int row) {
        
        if (pieceType == null) {
            throw new InvalidPieceException("Piece type cannot be null.");
        }

        switch (pieceType) {
            case PAWN:
                return new Pawn(pieceType, color, column, row);
            
            case ROOK:
                return new Rook(pieceType, color, column, row);
            
            case KNIGHT:
                return new Knight(pieceType, color, column, row);
            
            case KING:
                return new King(pieceType, color, column, row);
            
            case QUEEN:
                return new Queen(pieceType, color, column, row);
            
            default:
                throw new InvalidPieceException(
                    "This piece type cannot be created as a Figure: " + pieceType
                );
        }
    }

    /**
     * Displays the piece description, target position, and movement result.
     *
     * Method author: Aredth Sanchez.
     * @param description readable description of the piece.
     * @param targetColumn destination column as a LocationX value.
     * @param targetRow destination row number.
     * @param result true for a valid move; false for an invalid move.
     */
    public static void printMoveResult(String description, LocationX targetColumn, int targetRow, boolean result) {

        System.out.println(description + (result ? " can move to target position " : " cannot move to target position ") + targetColumn + targetRow);
    }
}
